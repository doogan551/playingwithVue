/*var monitorSender = new(require('MonitorSender').Tasks)();

monitorSender.serverMonitor("{ \"Command Type\" : 10 }", function(err, result) {
	// only returns errors
	console.log("serverMonitor returned error");
	console.log(result);
});*/