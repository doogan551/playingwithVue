var tester = {
	'Infoscan': {
		'files': {
			'driveLetter': 'C'
		}
	}
};

module.exports = tester;